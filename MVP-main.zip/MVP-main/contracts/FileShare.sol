// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract FileShare {
    struct Transaction {
        address owner;
        address receiver;
        string filename;
        string hash;
        uint256 timestamp;
    }

    Transaction[] private transactions;

    event FileShared(
        address indexed owner,
        address indexed receiver,
        string filename,
        string hash,
        uint256 timestamp
    );

    function shareFile(
        address receiver,
        string memory filename,
        string memory hash
    ) public {
        require(receiver != address(0), "Invalid receiver");
        require(bytes(filename).length > 0, "Filename required");
        require(bytes(hash).length > 0, "Hash required");

        Transaction memory txRecord = Transaction({
            owner: msg.sender,
            receiver: receiver,
            filename: filename,
            hash: hash,
            timestamp: block.timestamp
        });

        transactions.push(txRecord);

        emit FileShared(msg.sender, receiver, filename, hash, block.timestamp);
    }

    function getAllTransactions() public view returns (Transaction[] memory) {
        return transactions;
    }

    function getTransactionCount() public view returns (uint256) {
        return transactions.length;
    }
}
