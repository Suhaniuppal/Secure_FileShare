import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    const isAuthRoute =
      error.config?.url?.includes('/auth/login') ||
      error.config?.url?.includes('/auth/register');

    if (error.response?.status === 401 && !isAuthRoute) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export async function parseApiError(error, fallback = 'Request failed.') {
  if (error.response?.data instanceof Blob) {
    const text = await error.response.data.text();
    try {
      return JSON.parse(text).error || fallback;
    } catch {
      return text || fallback;
    }
  }
  return error.response?.data?.error || error.message || fallback;
}

export default api;
