import { BrowserProvider, Contract } from 'ethers';
import contractData from '../contract/FileShare.json';

export async function connectWallet() {
  if (!window.ethereum) {
    throw new Error('MetaMask is not installed.');
  }
  const provider = new BrowserProvider(window.ethereum);
  await provider.send('eth_requestAccounts', []);
  const signer = await provider.getSigner();
  const address = await signer.getAddress();
  return { provider, signer, address };
}

export async function shareFileOnChain(signer, receiverAddress, filename, hash) {
  if (!contractData.address) {
    throw new Error('Contract not deployed. Run hardhat deploy first.');
  }

  const contract = new Contract(contractData.address, contractData.abi, signer);
  const tx = await contract.shareFile(receiverAddress, filename, hash);
  await tx.wait();
  return tx.hash;
}

export async function getAllTransactions(provider) {
  if (!contractData.address) {
    return [];
  }

  const contract = new Contract(contractData.address, contractData.abi, provider);
  return contract.getAllTransactions();
}

export { contractData };
