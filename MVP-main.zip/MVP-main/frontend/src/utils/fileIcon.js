import {
  FileText,
  FileImage,
  FileArchive,
  FileSpreadsheet,
  FileVideo,
  FileAudio,
  FileCode,
} from 'lucide-react';

const TYPES = {
  pdf: { icon: FileText, color: '#ef4444', label: 'PDF' },
  doc: { icon: FileText, color: '#2563eb', label: 'Word' },
  docx: { icon: FileText, color: '#2563eb', label: 'Word' },
  xls: { icon: FileSpreadsheet, color: '#059669', label: 'Excel' },
  xlsx: { icon: FileSpreadsheet, color: '#059669', label: 'Excel' },
  csv: { icon: FileSpreadsheet, color: '#059669', label: 'CSV' },
  zip: { icon: FileArchive, color: '#f59e0b', label: 'ZIP' },
  rar: { icon: FileArchive, color: '#f59e0b', label: 'Archive' },
  '7z': { icon: FileArchive, color: '#f59e0b', label: 'Archive' },
  png: { icon: FileImage, color: '#8b5cf6', label: 'Image' },
  jpg: { icon: FileImage, color: '#8b5cf6', label: 'Image' },
  jpeg: { icon: FileImage, color: '#8b5cf6', label: 'Image' },
  gif: { icon: FileImage, color: '#8b5cf6', label: 'Image' },
  webp: { icon: FileImage, color: '#8b5cf6', label: 'Image' },
  svg: { icon: FileImage, color: '#8b5cf6', label: 'Image' },
  mp4: { icon: FileVideo, color: '#ec4899', label: 'Video' },
  mov: { icon: FileVideo, color: '#ec4899', label: 'Video' },
  avi: { icon: FileVideo, color: '#ec4899', label: 'Video' },
  mp3: { icon: FileAudio, color: '#06b6d4', label: 'Audio' },
  wav: { icon: FileAudio, color: '#06b6d4', label: 'Audio' },
  txt: { icon: FileText, color: '#94a3b8', label: 'Text' },
  md: { icon: FileText, color: '#94a3b8', label: 'Text' },
  js: { icon: FileCode, color: '#eab308', label: 'Code' },
  ts: { icon: FileCode, color: '#3b82f6', label: 'Code' },
  jsx: { icon: FileCode, color: '#61dafb', label: 'Code' },
  tsx: { icon: FileCode, color: '#61dafb', label: 'Code' },
  sol: { icon: FileCode, color: '#6366f1', label: 'Solidity' },
};

export function getFileType(filename = '') {
  const ext = filename.split('.').pop()?.toLowerCase() || '';
  return TYPES[ext] || { icon: FileText, color: '#6366f1', label: 'File' };
}
