import api, { parseApiError } from './api';

export async function downloadFile(fileId, filename) {
  const response = await api.get(`/files/download/${fileId}`, {
    responseType: 'blob',
  });

  const url = window.URL.createObjectURL(new Blob([response.data]));
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.URL.revokeObjectURL(url);
}

export async function downloadFileSafe(fileId, filename) {
  try {
    await downloadFile(fileId, filename);
    return { ok: true };
  } catch (err) {
    return { ok: false, error: await parseApiError(err, 'Download failed.') };
  }
}
