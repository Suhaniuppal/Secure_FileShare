import { Link, Navigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Shield,
  Lock,
  Hash,
  Blocks,
  KeyRound,
  Share2,
  ArrowRight,
  GitBranch,
  Zap,
} from 'lucide-react';
import CyberBackground from '../components/CyberBackground';
import Button from '../components/Button';
import GlassCard from '../components/GlassCard';
import { fadeUp, staggerContainer } from '../components/PageTransition';
import { getToken } from '../utils/auth';

const features = [
  { icon: Lock, title: 'AES-256 Encryption', desc: 'Military-grade encryption before storage' },
  { icon: Hash, title: 'SHA-256 Integrity', desc: 'Verify file authenticity with cryptographic hashes' },
  { icon: Blocks, title: 'Ethereum Blockchain', desc: 'Immutable transaction records on-chain' },
  { icon: KeyRound, title: 'JWT Authentication', desc: 'Secure token-based user sessions' },
  { icon: Share2, title: 'Secure File Sharing', desc: 'Share encrypted files with trusted users' },
];

const stack = ['React', 'Node.js', 'Express', 'MySQL', 'Ethereum', 'Hardhat', 'MetaMask'];

export default function Landing() {
  if (getToken()) return <Navigate to="/dashboard" replace />;

  return (
    <div className="landing">
      <CyberBackground variant="landing" />

      <nav className="landing-nav">
        <Link to="/" className="landing-nav-brand">
          <motion.div
            className="landing-nav-logo"
            whileHover={{ scale: 1.08, boxShadow: '0 0 30px rgba(99,102,241,0.6)' }}
          >
            <Shield size={22} />
          </motion.div>
          <span>SecureShare</span>
        </Link>
        <div className="landing-nav-actions">
          <Link to="/login" className="landing-nav-link">Login</Link>
          <Link to="/register">
            <Button variant="primary" size="sm">Register</Button>
          </Link>
        </div>
      </nav>

      <motion.section
        className="landing-hero"
        variants={staggerContainer}
        initial="initial"
        animate="animate"
      >
        <motion.div variants={fadeUp} className="landing-hero-badge">
          <Zap size={14} /> Web3 + Cyber Security
        </motion.div>

        <motion.div variants={fadeUp} className="landing-hero-logo">
          <motion.div
            animate={{ rotate: [0, 5, -5, 0], scale: [1, 1.05, 1] }}
            transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
          >
            <Shield size={64} />
          </motion.div>
        </motion.div>

        <motion.h1 variants={fadeUp}>
          Blockchain-Based<br />
          <span className="gradient-text">Secure File Sharing</span> System
        </motion.h1>

        <motion.p variants={fadeUp} className="landing-hero-desc">
          Encrypt, store, and share files with AES-256 encryption, SHA-256 integrity
          verification, and Ethereum blockchain transaction records — all in one platform.
        </motion.p>

        <motion.div variants={fadeUp} className="landing-hero-cta">
          <Link to="/register">
            <Button variant="primary" size="lg">
              Get Started <ArrowRight size={18} />
            </Button>
          </Link>
          <Link to="/login">
            <Button variant="secondary" size="lg">Login</Button>
          </Link>
        </motion.div>
      </motion.section>

      <section className="landing-section">
        <h2>Core Features</h2>
        <div className="landing-features">
          {features.map(({ icon: Icon, title, desc }, i) => (
            <GlassCard key={title} delay={i * 0.08} className="feature-card">
              <div className="feature-card__icon">
                <Icon size={22} />
              </div>
              <h3>{title}</h3>
              <p>{desc}</p>
            </GlassCard>
          ))}
        </div>
      </section>

      <section className="landing-section">
        <h2>Architecture</h2>
        <GlassCard className="arch-card" hover={false}>
          <div className="arch-flow">
            <div className="arch-node">React UI</div>
            <div className="arch-arrow">→</div>
            <div className="arch-node">Express API</div>
            <div className="arch-arrow">→</div>
            <div className="arch-node">AES Encrypt</div>
            <div className="arch-arrow">→</div>
            <div className="arch-node">MySQL + Uploads</div>
            <div className="arch-arrow">→</div>
            <div className="arch-node">Ethereum</div>
          </div>
          <p className="arch-desc">
            Files are encrypted server-side, metadata stored in MySQL, encrypted blobs saved
            locally, and file hashes recorded on the Ethereum blockchain via smart contract.
          </p>
        </GlassCard>
      </section>

      <section className="landing-section">
        <h2>Technology Stack</h2>
        <div className="landing-stack">
          {stack.map((tech) => (
            <span key={tech} className="stack-badge">{tech}</span>
          ))}
        </div>
      </section>

      <footer className="landing-footer">
        <div className="landing-footer-inner">
          <div>
            <strong>SecureShare MVP</strong>
            <p>Blockchain-Based Secure File Sharing System</p>
          </div>
          <a href="https://github.com" target="_blank" rel="noreferrer" className="landing-footer-github">
            <GitBranch size={18} /> GitHub
          </a>
        </div>
        <p className="landing-footer-copy">© 2025 SecureShare. Built for academic MVP demonstration.</p>
      </footer>
    </div>
  );
}
