import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Upload, Share2, Download, ShieldCheck, Hash } from 'lucide-react';
import api, { parseApiError } from '../utils/api';
import { downloadFileSafe } from '../utils/download';
import { formatDate, truncateHash } from '../utils/format';
import GlassCard from '../components/GlassCard';
import Button from '../components/Button';
import FileTypeIcon from '../components/FileTypeIcon';
import { TableSkeleton } from '../components/Skeleton';
import notify from '../utils/toast';

export default function MyFiles() {
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [downloading, setDownloading] = useState(null);

  useEffect(() => {
    api
      .get('/files/my-uploads')
      .then((res) => setFiles(res.data))
      .catch((err) => parseApiError(err, 'Failed to load files.').then((m) => notify.error(m)))
      .finally(() => setLoading(false));
  }, []);

  async function handleDownload(fileId, filename) {
    setDownloading(fileId);
    notify.success('Download started — decrypting file...');
    const result = await downloadFileSafe(fileId, filename);
    if (!result.ok) notify.error(result.error);
    else notify.success('File downloaded successfully!');
    setDownloading(null);
  }

  return (
    <>
      <div className="page-header">
        <div>
          <h1>My Files</h1>
          <p>{files.length} file{files.length !== 1 ? 's' : ''} stored securely on blockchain</p>
        </div>
        <div className="page-header-actions">
          <Link to="/verify"><Button variant="outline"><ShieldCheck size={16} /> Verify Integrity</Button></Link>
          <Link to="/upload"><Button variant="primary"><Upload size={16} /> Upload New File</Button></Link>
        </div>
      </div>

      <GlassCard hover={false}>
        {loading ? (
          <TableSkeleton rows={5} cols={5} />
        ) : files.length === 0 ? (
          <p className="table-empty">No files uploaded yet.</p>
        ) : (
          <table className="modern-table">
            <thead>
              <tr><th>File Name</th><th>Size</th><th>Upload Date</th><th>Hash (SHA-256)</th><th>Actions</th></tr>
            </thead>
            <tbody>
              {files.map((file) => (
                <tr key={file.id}>
                  <td><div className="file-cell"><FileTypeIcon filename={file.filename} />{file.filename}</div></td>
                  <td>—</td>
                  <td>{formatDate(file.created_at)}</td>
                  <td className="hash-mono"><Hash size={12} style={{ display: 'inline', marginRight: 4, verticalAlign: -2 }} />{truncateHash(file.hash)}</td>
                  <td>
                    <div className="actions-row">
                      <Link to="/upload"><Button variant="secondary" size="sm"><Share2 size={14} /> Share</Button></Link>
                      <Button variant="success" size="sm" onClick={() => handleDownload(file.id, file.filename)} loading={downloading === file.id} disabled={downloading === file.id}>
                        <Download size={14} /> Download
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </GlassCard>
    </>
  );
}
