import { useEffect, useState } from 'react';
import { Copy, Shield, Calendar } from 'lucide-react';
import { getUser } from '../utils/auth';
import { getInitials } from '../utils/format';
import { contractData } from '../utils/contract';
import api, { parseApiError } from '../utils/api';
import GlassCard from '../components/GlassCard';
import Button from '../components/Button';
import { StatSkeleton } from '../components/Skeleton';
import notify from '../utils/toast';

export default function Profile() {
  const user = getUser();
  const [stats, setStats] = useState({ uploads: 0, shared: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api
      .get('/files/stats')
      .then((res) => setStats(res.data))
      .catch((err) => parseApiError(err, 'Failed to load profile.').then((m) => notify.error(m)))
      .finally(() => setLoading(false));
  }, []);

  function copyWallet() {
    if (user?.wallet_address) {
      navigator.clipboard.writeText(user.wallet_address);
      notify.success('Wallet address copied!');
    }
  }

  return (
    <>
      <div className="page-header">
        <div>
          <h1>Profile</h1>
          <p>Your account details and security information</p>
        </div>
      </div>

      <div className="profile-grid">
        <GlassCard hover={false}>
          <div className="profile-hero">
            <div className="profile-avatar-xl">{getInitials(user?.username)}</div>
            <div>
              <h2 style={{ fontSize: '1.25rem', marginBottom: '.25rem' }}>{user?.username}</h2>
              <p style={{ color: 'var(--muted)', fontSize: '.875rem' }}>{user?.email}</p>
              <div style={{ marginTop: '.75rem' }}>
                <span className="security-badge"><Shield size={12} /> Security Level: High</span>
              </div>
            </div>
          </div>

          <div className="profile-row">
            <label>Username</label>
            <span>{user?.username}</span>
          </div>
          <div className="profile-row">
            <label>Email</label>
            <span>{user?.email}</span>
          </div>
          <div className="profile-row">
            <label><Calendar size={14} style={{ display: 'inline', marginRight: 4, verticalAlign: -2 }} />Member Since</label>
            <span>2025</span>
          </div>
          <div className="profile-row">
            <label>Wallet Address</label>
            <span style={{ display: 'flex', alignItems: 'center', gap: '.5rem' }}>
              {user?.wallet_address ? `${user.wallet_address.slice(0, 10)}...${user.wallet_address.slice(-6)}` : '—'}
              {user?.wallet_address && (
                <button type="button" className="copy-btn" onClick={copyWallet} aria-label="Copy wallet">
                  <Copy size={14} />
                </button>
              )}
            </span>
          </div>
          <div className="profile-row">
            <label>Smart Contract</label>
            <span>{contractData.address ? `${contractData.address.slice(0, 10)}...` : 'Not deployed'}</span>
          </div>
        </GlassCard>

        <GlassCard hover={false}>
          <h3 style={{ marginBottom: '1rem', fontSize: '1rem' }}>Activity Summary</h3>
          {loading ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <StatSkeleton />
              <StatSkeleton />
            </div>
          ) : (
            <div className="profile-stat-grid">
              <div className="profile-stat">
                <div className="profile-stat__val">{stats.uploads}</div>
                <div className="profile-stat__label">Files Uploaded</div>
              </div>
              <div className="profile-stat">
                <div className="profile-stat__val">{stats.shared}</div>
                <div className="profile-stat__label">Files Shared With You</div>
              </div>
            </div>
          )}

          <div style={{ marginTop: '1.5rem' }}>
            <Button variant="outline" size="sm" onClick={copyWallet} style={{ width: '100%' }}>
              <Copy size={14} /> Copy Wallet Address
            </Button>
          </div>
        </GlassCard>
      </div>
    </>
  );
}
