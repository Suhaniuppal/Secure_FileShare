import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Upload, FileText, Share2, Download, HardDrive, Shield, Wallet } from 'lucide-react';
import api, { parseApiError } from '../utils/api';
import { getUser } from '../utils/auth';
import { contractData } from '../utils/contract';
import { formatDate } from '../utils/format';
import GlassCard from '../components/GlassCard';
import Button from '../components/Button';
import AnimatedCounter from '../components/AnimatedCounter';
import FileTypeIcon from '../components/FileTypeIcon';
import { StatSkeleton, TableSkeleton } from '../components/Skeleton';
import { fadeUp, staggerContainer } from '../components/PageTransition';
import notify from '../utils/toast';

export default function Dashboard() {
  const user = getUser();
  const [stats, setStats] = useState({ uploads: 0, shared: 0 });
  const [recentUploads, setRecentUploads] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const [statsRes, uploadsRes] = await Promise.all([
          api.get('/files/stats'),
          api.get('/files/my-uploads'),
        ]);
        setStats(statsRes.data);
        setRecentUploads(uploadsRes.data.slice(0, 5));
      } catch (err) {
        notify.error(await parseApiError(err, 'Failed to load dashboard.'));
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  const statCards = [
    { icon: FileText, color: 'blue', value: stats.uploads, label: 'Total Files' },
    { icon: Share2, color: 'purple', value: stats.uploads, label: 'Files Shared' },
    { icon: Download, color: 'green', value: stats.shared, label: 'Files Received' },
    { icon: HardDrive, color: 'orange', value: stats.uploads * 2.4, label: 'Storage (MB)', suffix: '' },
  ];

  return (
    <>
      <div className="page-header">
        <div>
          <h1>Dashboard</h1>
          <p>Welcome back, {user?.username}! Here&apos;s an overview of your secure files.</p>
        </div>
        <div className="page-header-actions">
          <Link to="/upload"><Button variant="primary"><Upload size={16} /> Upload File</Button></Link>
        </div>
      </div>

      <motion.div className="stats-grid" variants={staggerContainer} initial="initial" animate="animate">
        {loading
          ? Array.from({ length: 4 }).map((_, i) => <StatSkeleton key={i} />)
          : statCards.map(({ icon: Icon, color, value, label }, i) => (
              <motion.div key={label} variants={fadeUp}>
                <GlassCard className="stat-card" delay={i * 0.05}>
                  <div className={`stat-card__icon stat-card__icon--${color}`}>
                    <Icon size={22} />
                  </div>
                  <div>
                    <div className="stat-card__value">
                      <AnimatedCounter value={Math.round(value)} />
                      {label.includes('MB') ? ' MB' : ''}
                    </div>
                    <div className="stat-card__label">{label}</div>
                  </div>
                </GlassCard>
              </motion.div>
            ))}
      </motion.div>

      <div className="dashboard-grid">
        <GlassCard hover={false}>
          <h2 className="white-card-title" style={{ marginBottom: '1rem', fontSize: '1rem', fontWeight: 700 }}>Recent Files</h2>
          {loading ? (
            <TableSkeleton rows={4} cols={4} />
          ) : recentUploads.length === 0 ? (
            <p className="table-empty">No files yet. Upload your first file to get started.</p>
          ) : (
            <table className="modern-table">
              <thead>
                <tr><th>File Name</th><th>Receiver</th><th>Date</th><th>Hash</th></tr>
              </thead>
              <tbody>
                {recentUploads.map((file) => (
                  <tr key={file.id}>
                    <td><div className="file-cell"><FileTypeIcon filename={file.filename} />{file.filename}</div></td>
                    <td>{file.receiver_name}</td>
                    <td>{formatDate(file.created_at)}</td>
                    <td className="hash-mono">{file.hash.slice(0, 12)}...</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </GlassCard>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.15rem' }}>
          <GlassCard delay={0.1}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '.75rem', marginBottom: '.75rem' }}>
              <Shield size={20} color="#22C55E" />
              <strong>Security Status</strong>
            </div>
            <span className="security-badge">All Systems Secure</span>
            <p style={{ color: 'var(--muted)', fontSize: '.8rem', marginTop: '.75rem' }}>AES-256 encryption active. JWT session valid.</p>
          </GlassCard>

          <GlassCard delay={0.15}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '.75rem', marginBottom: '.75rem' }}>
              <Wallet size={20} color="#6366F1" />
              <strong>Wallet</strong>
            </div>
            <p className="hash-mono" style={{ fontSize: '.75rem' }}>{user?.wallet_address?.slice(0, 16)}...</p>
            <p style={{ color: 'var(--muted)', fontSize: '.75rem', marginTop: '.5rem' }}>
              Contract: {contractData.address ? `${contractData.address.slice(0, 8)}...` : 'Not deployed'}
            </p>
          </GlassCard>

          <GlassCard delay={0.2}>
            <strong style={{ display: 'block', marginBottom: '.75rem' }}>Recent Activity</strong>
            <ul className="timeline">
              {recentUploads.slice(0, 3).map((f) => (
                <li key={f.id}>
                  <span className="timeline__dot" />
                  <div>
                    <div>Shared {f.filename}</div>
                    <div className="timeline__time">{formatDate(f.created_at)}</div>
                  </div>
                </li>
              ))}
              {recentUploads.length === 0 && <li style={{ color: 'var(--muted)' }}>No recent activity</li>}
            </ul>
          </GlassCard>
        </div>
      </div>
    </>
  );
}
