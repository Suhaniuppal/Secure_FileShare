import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { UserPlus, User, Mail, Lock } from 'lucide-react';
import CyberBackground from '../components/CyberBackground';
import AuthHero from '../components/AuthHero';
import Button from '../components/Button';
import GlassCard from '../components/GlassCard';
import PageTransition from '../components/PageTransition';
import api, { parseApiError } from '../utils/api';
import { setAuth } from '../utils/auth';
import { connectWallet } from '../utils/contract';
import notify from '../utils/toast';

const WALLET_REGEX = /^0x[a-fA-F0-9]{40}$/;

export default function Register() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ username: '', email: '', password: '', wallet_address: '' });
  const [loading, setLoading] = useState(false);

  function updateField(field, value) {
    setForm((prev) => ({ ...prev, [field]: value }));
  }

  async function handleConnectWallet() {
    try {
      const { address } = await connectWallet();
      updateField('wallet_address', address);
      notify.success('MetaMask connected!');
    } catch (err) {
      notify.error(err.message);
    }
  }

  async function handleSubmit(e) {
    e.preventDefault();

    if (!WALLET_REGEX.test(form.wallet_address)) {
      notify.error('Enter a valid Ethereum wallet address or connect MetaMask.');
      return;
    }

    setLoading(true);

    try {
      const { data } = await api.post('/auth/register', form);
      setAuth(data.token, data.user);
      notify.success('Registration successful! Welcome to SecureShare.');
      navigate('/dashboard');
    } catch (err) {
      notify.error(await parseApiError(err, 'Registration failed.'));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="auth-page">
      <CyberBackground />
      <AuthHero
        title="Secure Your Files"
        subtitle="Join SecureShare and experience blockchain-powered file sharing with SHA-256 integrity verification."
      />

      <div className="auth-form-panel">
        <PageTransition>
          <GlassCard className="auth-card" hover={false}>
            <div className="feature-card__icon" style={{ margin: '0 auto 1rem' }}>
              <UserPlus size={22} />
            </div>
            <h2>Create an Account</h2>
            <p className="auth-card-sub">Start sharing files securely today</p>

            <form onSubmit={handleSubmit}>
              <div className="auth-field">
                <label htmlFor="username">Full Name</label>
                <div className="auth-input-wrap">
                  <User size={16} className="auth-input-icon" />
                  <input id="username" className="auth-input" type="text" value={form.username}
                    onChange={(e) => updateField('username', e.target.value)} placeholder="Enter your full name" required />
                </div>
              </div>
              <div className="auth-field">
                <label htmlFor="email">Email</label>
                <div className="auth-input-wrap">
                  <Mail size={16} className="auth-input-icon" />
                  <input id="email" className="auth-input" type="email" value={form.email}
                    onChange={(e) => updateField('email', e.target.value)} placeholder="Enter your email" required />
                </div>
              </div>
              <div className="auth-field">
                <label htmlFor="password">Password</label>
                <div className="auth-input-wrap">
                  <Lock size={16} className="auth-input-icon" />
                  <input id="password" className="auth-input" type="password" value={form.password}
                    onChange={(e) => updateField('password', e.target.value)} placeholder="Create a password" required minLength={6} />
                </div>
              </div>
              <div className="auth-field">
                <label htmlFor="wallet">Wallet Address</label>
                <div className="auth-input-wrap">
                  <Lock size={16} className="auth-input-icon" />
                  <input id="wallet" className="auth-input" type="text" value={form.wallet_address}
                    onChange={(e) => updateField('wallet_address', e.target.value.trim())} placeholder="0x... or connect MetaMask" required />
                </div>
                <Button type="button" variant="outline" size="sm" onClick={handleConnectWallet} style={{ marginTop: '0.5rem', width: '100%' }}>
                  Connect MetaMask
                </Button>
              </div>
              <Button type="submit" variant="primary" loading={loading} style={{ width: '100%' }}>Register</Button>
            </form>

            <p className="auth-footer">
              Already have an account? <Link to="/login">Login</Link>
            </p>
          </GlassCard>
        </PageTransition>
      </div>
    </div>
  );
}
