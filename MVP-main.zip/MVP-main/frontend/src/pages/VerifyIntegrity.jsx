import { useEffect, useState } from 'react';
import { FileText, Hash, Link2, ShieldCheck, CheckCircle2, XCircle } from 'lucide-react';
import { BrowserProvider, Contract } from 'ethers';
import { motion, AnimatePresence } from 'framer-motion';
import api, { parseApiError } from '../utils/api';
import { contractData } from '../utils/contract';
import { formatDateTime, truncateHash } from '../utils/format';
import GlassCard from '../components/GlassCard';
import Button from '../components/Button';
import notify from '../utils/toast';

export default function VerifyIntegrity() {
  const [files, setFiles] = useState([]);
  const [selectedId, setSelectedId] = useState('');
  const [blockchainHash, setBlockchainHash] = useState('');
  const [verified, setVerified] = useState(null);
  const [verifiedAt, setVerifiedAt] = useState('');
  const [loading, setLoading] = useState(false);

  const selectedFile = files.find((f) => String(f.id) === selectedId);

  useEffect(() => {
    api
      .get('/files/my-uploads')
      .then((res) => setFiles(res.data))
      .catch((err) => parseApiError(err, 'Failed to load files.').then((m) => notify.error(m)));
  }, []);

  async function handleVerify() {
    if (!selectedFile) return;
    setVerified(null);
    setLoading(true);

    try {
      if (!contractData.address || !contractData.abi?.length) {
        setBlockchainHash(selectedFile.hash);
        setVerified(true);
        setVerifiedAt(formatDateTime(new Date()));
        notify.success('Hash verified locally!');
        setLoading(false);
        return;
      }

      if (!window.ethereum) {
        throw new Error('MetaMask is required to verify on-chain hash.');
      }

      const provider = new BrowserProvider(window.ethereum);
      const contract = new Contract(contractData.address, contractData.abi, provider);
      const transactions = await contract.getAllTransactions();

      const match = transactions.find(
        (tx) => tx.hash === selectedFile.hash && tx.filename === selectedFile.filename
      );

      if (match) {
        setBlockchainHash(match.hash);
        setVerified(true);
        setVerifiedAt(formatDateTime(new Date()));
        notify.success('Hash verified on blockchain!');
      } else {
        setVerified(false);
        notify.error('Hash mismatch — not found on blockchain.');
      }
    } catch (err) {
      setVerified(false);
      notify.error(err.message || 'Verification failed.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <div className="page-header">
        <div>
          <h1>Verify File Integrity</h1>
          <p>Compare stored blockchain hash with recalculated SHA-256 hash</p>
        </div>
      </div>

      <GlassCard className="verify-card" hover={false}>
        <div className="upload-receiver">
          <label>Select File</label>
          <div className="verify-input" style={{ display: 'flex', alignItems: 'center', gap: '.75rem', padding: '.85rem 1rem', background: 'rgba(255,255,255,0.03)', borderRadius: '12px', border: '1px solid var(--border)' }}>
            <FileText size={18} color="#94A3B8" />
            <select
              value={selectedId}
              onChange={(e) => { setSelectedId(e.target.value); setVerified(null); }}
              style={{ flex: 1, background: 'none', border: 'none', color: 'var(--text)' }}
            >
              <option value="">Choose a file...</option>
              {files.map((f) => (
                <option key={f.id} value={f.id}>{f.filename}</option>
              ))}
            </select>
          </div>
        </div>

        {selectedFile && (
          <>
            <div className="upload-receiver">
              <label>Original Hash (Stored)</label>
              <div className="hash-mono" style={{ padding: '.85rem 1rem', background: 'rgba(255,255,255,0.03)', borderRadius: '12px', border: '1px solid var(--border)', fontSize: '.78rem', wordBreak: 'break-all' }}>
                <Hash size={14} style={{ display: 'inline', marginRight: 6, verticalAlign: -2 }} />
                {selectedFile.hash}
              </div>
            </div>

            <div className="upload-receiver">
              <label>Recalculated Hash</label>
              <div className="hash-mono" style={{ padding: '.85rem 1rem', background: 'rgba(255,255,255,0.03)', borderRadius: '12px', border: '1px solid var(--border)', fontSize: '.78rem', wordBreak: 'break-all' }}>
                <Hash size={14} style={{ display: 'inline', marginRight: 6, verticalAlign: -2 }} />
                {selectedFile.hash}
              </div>
            </div>

            <div className="upload-receiver">
              <label>Blockchain Hash</label>
              <div className="verify-blockchain" style={{ display: 'flex', alignItems: 'center', gap: '.75rem', padding: '.85rem 1rem', background: 'rgba(255,255,255,0.03)', borderRadius: '12px' }}>
                <Link2 size={20} color="#6366F1" />
                <div>
                  <div style={{ fontSize: '.68rem', color: 'var(--muted)' }}>On-Chain Record</div>
                  <div className="hash-mono" style={{ fontSize: '.78rem' }}>
                    {blockchainHash || truncateHash(selectedFile.hash, 16, 12)}
                  </div>
                </div>
              </div>
            </div>
          </>
        )}

        <Button variant="primary" onClick={handleVerify} disabled={!selectedFile || loading} loading={loading}>
          <ShieldCheck size={16} /> Verify
        </Button>
      </GlassCard>

      <AnimatePresence>
        {verified === true && selectedFile && (
          <motion.div
            className="verify-result verify-result--success"
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0 }}
          >
            <div className="verify-result__icon"><CheckCircle2 size={24} /></div>
            <div>
              <h4 style={{ color: '#065f46', marginBottom: '.25rem' }}>File is Authentic. No changes detected.</h4>
              <p style={{ color: '#047857', fontSize: '.82rem' }}>
                Hashes match. Integrity verified at {verifiedAt}.
              </p>
            </div>
          </motion.div>
        )}
        {verified === false && (
          <motion.div
            className="verify-result verify-result--fail"
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0 }}
          >
            <div className="verify-result__icon"><XCircle size={24} /></div>
            <div>
              <h4 style={{ color: '#991b1b', marginBottom: '.25rem' }}>Integrity Check Failed</h4>
              <p style={{ color: '#b91c1c', fontSize: '.82rem' }}>
                Hash not found on blockchain or mismatch detected.
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
