import { useEffect, useState } from 'react';
import { Download } from 'lucide-react';
import api, { parseApiError } from '../utils/api';
import { downloadFileSafe } from '../utils/download';
import { formatDate } from '../utils/format';
import GlassCard from '../components/GlassCard';
import Button from '../components/Button';
import FileTypeIcon from '../components/FileTypeIcon';
import { TableSkeleton } from '../components/Skeleton';
import notify from '../utils/toast';

export default function SharedFiles() {
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [downloading, setDownloading] = useState(null);

  useEffect(() => {
    api
      .get('/files/shared')
      .then((res) => setFiles(res.data))
      .catch((err) => parseApiError(err, 'Failed to load files.').then((m) => notify.error(m)))
      .finally(() => setLoading(false));
  }, []);

  async function handleDownload(fileId, filename) {
    setDownloading(fileId);
    notify.success('Download started — decrypting file...');
    const result = await downloadFileSafe(fileId, filename);
    if (!result.ok) notify.error(result.error);
    else notify.success('File downloaded successfully!');
    setDownloading(null);
  }

  return (
    <>
      <div className="page-header">
        <div>
          <h1>Shared With Me</h1>
          <p>{files.length} file{files.length !== 1 ? 's' : ''} shared with you by other users</p>
        </div>
      </div>

      <GlassCard hover={false}>
        {loading ? (
          <TableSkeleton rows={5} cols={5} />
        ) : files.length === 0 ? (
          <p className="table-empty">No shared files yet.</p>
        ) : (
          <table className="modern-table">
            <thead>
              <tr><th>File Name</th><th>Shared By</th><th>Permission</th><th>Shared Date</th><th>Action</th></tr>
            </thead>
            <tbody>
              {files.map((file) => (
                <tr key={file.id}>
                  <td><div className="file-cell"><FileTypeIcon filename={file.filename} />{file.filename}</div></td>
                  <td>{file.owner_name}</td>
                  <td><span className="badge badge-blue">Download</span></td>
                  <td>{formatDate(file.created_at)}</td>
                  <td>
                    <Button variant="success" size="sm" onClick={() => handleDownload(file.id, file.filename)} loading={downloading === file.id}>
                      <Download size={14} /> Download
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </GlassCard>
    </>
  );
}
