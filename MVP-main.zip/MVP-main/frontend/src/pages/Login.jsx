import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { LogIn, Mail, Lock } from 'lucide-react';
import CyberBackground from '../components/CyberBackground';
import AuthHero from '../components/AuthHero';
import Button from '../components/Button';
import GlassCard from '../components/GlassCard';
import PageTransition from '../components/PageTransition';
import api, { parseApiError } from '../utils/api';
import { setAuth } from '../utils/auth';
import notify from '../utils/toast';

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);

    try {
      const { data } = await api.post('/auth/login', { email, password });
      setAuth(data.token, data.user);
      notify.success('Login successful! Welcome back.');
      navigate('/dashboard');
    } catch (err) {
      notify.error(await parseApiError(err, 'Login failed.'));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="auth-page">
      <CyberBackground />
      <AuthHero
        title="Welcome Back"
        subtitle="Access your secure files stored on the blockchain with verified SHA-256 integrity checks."
      />

      <div className="auth-form-panel">
        <PageTransition>
          <GlassCard className="auth-card" hover={false}>
            <motion.div
              className="feature-card__icon"
              style={{ margin: '0 auto 1rem' }}
              whileHover={{ rotate: 5 }}
            >
              <LogIn size={22} />
            </motion.div>
            <h2>Welcome Back</h2>
            <p className="auth-card-sub">Sign in to your SecureShare account</p>

            <form onSubmit={handleSubmit}>
              <div className="auth-field">
                <label htmlFor="email">Email</label>
                <div className="auth-input-wrap">
                  <Mail size={16} className="auth-input-icon" />
                  <input
                    id="email"
                    className="auth-input"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email"
                    required
                  />
                </div>
              </div>

              <div className="auth-field">
                <label htmlFor="password">Password</label>
                <div className="auth-input-wrap">
                  <Lock size={16} className="auth-input-icon" />
                  <input
                    id="password"
                    className="auth-input"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your password"
                    required
                  />
                </div>
              </div>

              <Button type="submit" variant="primary" loading={loading} className="auth-submit-btn" style={{ width: '100%' }}>
                Login
              </Button>
            </form>

            <p className="auth-footer">
              Don&apos;t have an account? <Link to="/register">Register</Link>
            </p>
          </GlassCard>
        </PageTransition>
      </div>
    </div>
  );
}
