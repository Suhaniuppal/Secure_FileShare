import { useEffect, useRef, useState } from 'react';
import { CloudUpload, X, Check } from 'lucide-react';
import api, { parseApiError } from '../utils/api';
import { getUser } from '../utils/auth';
import { formatFileSize } from '../utils/format';
import { getFileType } from '../utils/fileIcon';
import GlassCard from '../components/GlassCard';
import Button from '../components/Button';
import FileTypeIcon from '../components/FileTypeIcon';
import UploadSuccessCard from '../components/UploadSuccessCard';
import notify from '../utils/toast';

const STEPS = [
  'AES Encryption',
  'Database Storage',
  'Blockchain Recording',
  'Upload Complete',
];

export default function Upload() {
  const [users, setUsers] = useState([]);
  const [receiverId, setReceiverId] = useState('');
  const [file, setFile] = useState(null);
  const [dragOver, setDragOver] = useState(false);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [activeStep, setActiveStep] = useState(-1);
  const [successData, setSuccessData] = useState(null);
  const fileInputRef = useRef(null);
  const currentUser = getUser();

  useEffect(() => {
    api
      .get('/auth/users')
      .then((res) => setUsers(res.data.filter((u) => u.id !== currentUser?.id)))
      .catch((err) => parseApiError(err, 'Failed to load users.').then((m) => notify.error(m)));
  }, [currentUser?.id]);

  function handleFileSelect(selected) {
    if (selected) {
      setFile(selected);
      setSuccessData(null);
    }
  }

  function handleDrop(e) {
    e.preventDefault();
    setDragOver(false);
    handleFileSelect(e.dataTransfer.files[0]);
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!file || !receiverId) return;

    setLoading(true);
    setProgress(0);
    setActiveStep(0);
    setSuccessData(null);

    const stepTimer = setInterval(() => {
      setActiveStep((s) => (s < STEPS.length - 1 ? s + 1 : s));
      setProgress((p) => Math.min(p + 15, 85));
    }, 600);

    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('receiver_id', receiverId);

      const { data } = await api.post('/files/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });

      clearInterval(stepTimer);
      setActiveStep(STEPS.length - 1);
      setProgress(100);

      const receiver = users.find((u) => String(u.id) === String(receiverId));
      setSuccessData({ ...data.file, receiverName: receiver?.username });
      notify.success('File uploaded successfully!');
      if (data.file.transaction_hash) {
        notify.success('Blockchain transaction complete!');
      }

      setFile(null);
      setReceiverId('');
    } catch (err) {
      clearInterval(stepTimer);
      notify.error(await parseApiError(err, 'Upload failed.'));
      setActiveStep(-1);
      setProgress(0);
    } finally {
      setLoading(false);
    }
  }

  const receiverName = successData?.receiverName;

  return (
    <>
      <div className="page-header">
        <div>
          <h1>Upload File</h1>
          <p>Encrypt and store your file securely on the blockchain</p>
        </div>
      </div>

      <div
        className={`upload-dropzone glass-card${dragOver ? ' upload-dropzone--active' : ''}`}
        onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={handleDrop}
        onClick={() => !file && fileInputRef.current?.click()}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => e.key === 'Enter' && fileInputRef.current?.click()}
      >
        <div className="upload-dropzone__icon">
          <CloudUpload size={32} />
        </div>
        <h3>Drag &amp; Drop your file here</h3>
        <p>or browse to select a file from your device</p>
        <Button variant="outline" size="sm" onClick={(e) => { e.stopPropagation(); fileInputRef.current?.click(); }}>
          Browse File
        </Button>
        <input ref={fileInputRef} type="file" className="hidden-input" onChange={(e) => handleFileSelect(e.target.files[0])} />
      </div>

      {file && !successData && (
        <GlassCard className="upload-preview">
          <form onSubmit={handleSubmit}>
            <div className="upload-preview-row">
              <FileTypeIcon filename={file.name} size={20} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: '.72rem', color: 'var(--muted)' }}>File Name</div>
                <div style={{ fontWeight: 600 }}>{file.name}</div>
              </div>
              <button type="button" className="copy-btn" onClick={() => setFile(null)} aria-label="Remove">
                <X size={16} />
              </button>
            </div>

            <div className="upload-meta-grid">
              <div className="upload-meta-box">
                <label>File Name</label>
                <span>{file.name}</span>
              </div>
              <div className="upload-meta-box">
                <label>File Size</label>
                <span>{formatFileSize(file.size)}</span>
              </div>
              <div className="upload-meta-box">
                <label>File Type</label>
                <span>{getFileType(file.name).label}</span>
              </div>
            </div>

            <div className="upload-receiver">
              <label htmlFor="receiver">Share With</label>
              <select id="receiver" value={receiverId} onChange={(e) => setReceiverId(e.target.value)} required>
                <option value="">Select a user...</option>
                {users.map((user) => (
                  <option key={user.id} value={user.id}>
                    {user.username} ({user.wallet_address.slice(0, 8)}...)
                  </option>
                ))}
              </select>
            </div>

            {loading && (
              <>
                <div className="upload-stepper">
                  {STEPS.map((step, i) => (
                    <div
                      key={step}
                      className={`upload-step${i < activeStep ? ' upload-step--done' : ''}${i === activeStep ? ' upload-step--active' : ''}`}
                    >
                      <span className="upload-step__dot">{i < activeStep ? <Check size={12} /> : i + 1}</span>
                      {step}
                    </div>
                  ))}
                </div>
                <div className="upload-progress">
                  <div className="upload-progress__bar">
                    <div className="upload-progress__fill" style={{ width: `${progress}%` }} />
                  </div>
                  <div className="upload-progress__label">
                    <span>Uploading...</span>
                    <span>{progress}%</span>
                  </div>
                </div>
              </>
            )}

            <Button type="submit" variant="primary" loading={loading} disabled={!receiverId || users.length === 0} style={{ width: '100%' }}>
              <CloudUpload size={18} /> Upload
            </Button>
          </form>
        </GlassCard>
      )}

      {successData && (
        <UploadSuccessCard
          data={successData}
          receiverName={receiverName}
          onClose={() => { setSuccessData(null); setActiveStep(-1); setProgress(0); }}
        />
      )}
    </>
  );
}
