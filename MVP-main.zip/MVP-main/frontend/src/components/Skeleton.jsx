export function Skeleton({ width, height, className = '', circle = false }) {
  return (
    <div
      className={`skeleton ${circle ? 'skeleton--circle' : ''} ${className}`}
      style={{ width, height }}
    />
  );
}

export function TableSkeleton({ rows = 5, cols = 5 }) {
  return (
    <div className="table-skeleton">
      <div className="table-skeleton__head">
        {Array.from({ length: cols }).map((_, i) => (
          <Skeleton key={i} height={14} className="table-skeleton__cell" />
        ))}
      </div>
      {Array.from({ length: rows }).map((_, r) => (
        <div key={r} className="table-skeleton__row">
          {Array.from({ length: cols }).map((_, c) => (
            <Skeleton key={c} height={18} className="table-skeleton__cell" />
          ))}
        </div>
      ))}
    </div>
  );
}

export function StatSkeleton() {
  return (
    <div className="stat-skeleton glass-card">
      <Skeleton width={48} height={48} circle />
      <div className="stat-skeleton__text">
        <Skeleton width={60} height={28} />
        <Skeleton width={90} height={14} />
      </div>
    </div>
  );
}
