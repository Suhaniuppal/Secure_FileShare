import { motion } from 'framer-motion';

export default function Button({
  children,
  variant = 'primary',
  size = 'md',
  loading = false,
  disabled = false,
  className = '',
  type = 'button',
  ...props
}) {
  const isDisabled = disabled || loading;

  return (
    <motion.button
      type={type}
      className={`ui-btn ui-btn--${variant} ui-btn--${size} ${className}`}
      disabled={isDisabled}
      whileHover={isDisabled ? {} : { scale: 1.02 }}
      whileTap={isDisabled ? {} : { scale: 0.98 }}
      transition={{ type: 'spring', stiffness: 400, damping: 20 }}
      {...props}
    >
      {loading && <span className="ui-btn__spinner" />}
      <span className={loading ? 'ui-btn__text--loading' : ''}>{children}</span>
      <span className="ui-btn__ripple" />
    </motion.button>
  );
}
