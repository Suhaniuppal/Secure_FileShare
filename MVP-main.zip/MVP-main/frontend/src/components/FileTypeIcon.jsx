import { getFileType } from '../utils/fileIcon';

export default function FileTypeIcon({ filename, size = 18 }) {
  const { icon: Icon, color } = getFileType(filename);
  return (
    <div className="file-type-icon" style={{ '--file-color': color }}>
      <Icon size={size} />
    </div>
  );
}
