import { useEffect, useState } from 'react';
import { motion, useSpring, useTransform } from 'framer-motion';

export default function AnimatedCounter({ value, suffix = '', duration = 1.2 }) {
  const spring = useSpring(0, { stiffness: 60, damping: 20 });
  const display = useTransform(spring, (v) => Math.round(v));
  const [shown, setShown] = useState(0);

  useEffect(() => {
    spring.set(Number(value) || 0);
    const unsub = display.on('change', (v) => setShown(v));
    return unsub;
  }, [value, spring, display]);

  return (
    <motion.span className="animated-counter">
      {shown}{suffix}
    </motion.span>
  );
}
