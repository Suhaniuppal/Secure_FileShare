import { Shield, Lock, Check, Hash, Pause } from 'lucide-react';

export default function AuthHero({ title, subtitle }) {
  return (
    <div className="auth-hero-panel">
      <div className="auth-hero-visual">
        <div className="auth-shield-wrap">
          <div className="auth-float auth-float-1"><Lock size={14} /></div>
          <div className="auth-float auth-float-2"><Hash size={14} /></div>
          <div className="auth-float auth-float-3"><Pause size={14} /></div>
          <div className="auth-shield">
            <Shield size={120} strokeWidth={1.2} className="auth-shield-icon" />
            <Lock size={36} className="auth-shield-lock" />
            <div className="auth-shield-check"><Check size={14} strokeWidth={3} /></div>
          </div>
        </div>
      </div>
      <h1 className="auth-hero-title">{title}</h1>
      <p className="auth-hero-subtitle">{subtitle}</p>
    </div>
  );
}
