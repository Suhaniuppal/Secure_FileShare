import { motion } from 'framer-motion';
import { CheckCircle2, Copy, Link2, User, Clock } from 'lucide-react';
import { formatDateTime } from '../utils/format';
import notify from '../utils/toast';
import Button from './Button';

export default function UploadSuccessCard({ data, receiverName, onClose }) {
  const txHash = data?.transaction_hash || data?.hash;

  function copyHash() {
    navigator.clipboard.writeText(txHash || '');
    notify.success('Transaction hash copied!');
  }

  return (
    <motion.div
      className="upload-success glass-card"
      initial={{ opacity: 0, scale: 0.95, y: 20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      transition={{ type: 'spring', stiffness: 300, damping: 24 }}
    >
      <div className="upload-success__header">
        <div className="upload-success__icon">
          <CheckCircle2 size={28} />
        </div>
        <div>
          <h3>Upload Successful</h3>
          <p>{data?.filename} encrypted and stored securely</p>
        </div>
      </div>

      <div className="upload-success__grid">
        <div className="upload-success__item">
          <Link2 size={16} />
          <div>
            <span className="label">Transaction Hash</span>
            <code>{txHash ? `${txHash.slice(0, 24)}...` : data?.hash?.slice(0, 24)}...</code>
          </div>
          <button type="button" className="copy-btn" onClick={copyHash} aria-label="Copy hash">
            <Copy size={14} />
          </button>
        </div>
        <div className="upload-success__item">
          <User size={16} />
          <div>
            <span className="label">Receiver</span>
            <span>{receiverName || '—'}</span>
          </div>
        </div>
        <div className="upload-success__item">
          <Clock size={16} />
          <div>
            <span className="label">Timestamp</span>
            <span>{formatDateTime(new Date())}</span>
          </div>
        </div>
      </div>

      <div className="upload-success__status">
        <span className="badge badge-success">Blockchain Status: Recorded</span>
      </div>

      {onClose && (
        <Button variant="secondary" onClick={onClose} className="upload-success__close">
          Upload Another File
        </Button>
      )}
    </motion.div>
  );
}
