export default function CyberBackground({ variant = 'default' }) {
  return (
    <div className={`cyber-bg cyber-bg--${variant}`} aria-hidden="true">
      <div className="cyber-bg__mesh" />
      <div className="cyber-bg__grid" />
      <div className="cyber-bg__nodes">
        {Array.from({ length: 12 }).map((_, i) => (
          <span key={i} className="cyber-bg__node" style={{ '--i': i }} />
        ))}
      </div>
      <div className="cyber-bg__particles">
        {Array.from({ length: 20 }).map((_, i) => (
          <span key={i} className="cyber-bg__particle" style={{ '--i': i }} />
        ))}
      </div>
      <div className="cyber-bg__hexes">
        {Array.from({ length: 6 }).map((_, i) => (
          <span key={i} className="cyber-bg__hex" style={{ '--i': i }} />
        ))}
      </div>
    </div>
  );
}
