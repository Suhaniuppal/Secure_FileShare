import { useState } from 'react';
import { NavLink, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Shield,
  LayoutDashboard,
  FolderOpen,
  Upload,
  Share2,
  Users,
  User,
  LogOut,
  ShieldCheck,
  ChevronLeft,
  ChevronRight,
  Wallet,
} from 'lucide-react';
import { clearAuth, getUser } from '../utils/auth';
import { getInitials } from '../utils/format';
import { contractData } from '../utils/contract';

const navItems = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/my-files', label: 'My Files', icon: FolderOpen },
  { to: '/upload', label: 'Upload', icon: Upload },
  { to: '/shared', label: 'Shared With Me', icon: Share2 },
  { to: '/shared-by-me', label: 'Shared By Me', icon: Users },
  { to: '/verify', label: 'Verify', icon: ShieldCheck },
  { to: '/profile', label: 'Profile', icon: User },
];

export default function Sidebar() {
  const navigate = useNavigate();
  const user = getUser();
  const [collapsed, setCollapsed] = useState(false);
  const walletConnected = Boolean(user?.wallet_address);

  function handleLogout() {
    clearAuth();
    navigate('/login');
  }

  return (
    <motion.aside
      className={`sidebar ${collapsed ? 'sidebar--collapsed' : ''}`}
      animate={{ width: collapsed ? 72 : 260 }}
      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
    >
      <Link to="/dashboard" className="sidebar-brand">
        <motion.div
          className="sidebar-logo"
          whileHover={{ scale: 1.08, boxShadow: '0 0 24px rgba(99,102,241,0.5)' }}
          whileTap={{ scale: 0.95 }}
        >
          <Shield size={22} />
        </motion.div>
        {!collapsed && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <div className="sidebar-brand-name">SecureShare</div>
            <div className="sidebar-brand-tag">BLOCKCHAIN FILE SYSTEM</div>
          </motion.div>
        )}
      </Link>

      <div className="sidebar-profile">
        <div className="sidebar-avatar">{getInitials(user?.username)}</div>
        {!collapsed && (
          <div className="sidebar-profile-info">
            <div className="sidebar-profile-name">{user?.username || 'User'}</div>
            <div className="sidebar-profile-email">{user?.email || ''}</div>
            <div className={`wallet-status ${walletConnected ? 'wallet-status--on' : ''}`}>
              <Wallet size={12} />
              {walletConnected ? 'Wallet Connected' : 'No Wallet'}
            </div>
          </div>
        )}
      </div>

      <nav className="sidebar-nav">
        {navItems.map(({ to, label, icon: Icon }) => (
          <NavLink key={to} to={to} className="sidebar-link-wrap">
            {({ isActive }) => (
              <motion.div
                className={`sidebar-link ${isActive ? 'active' : ''}`}
                whileHover={{ x: 4 }}
                transition={{ type: 'spring', stiffness: 400, damping: 25 }}
              >
                {isActive && (
                  <motion.span
                    className="sidebar-link-indicator"
                    layoutId="sidebar-active"
                    transition={{ type: 'spring', stiffness: 350, damping: 30 }}
                  />
                )}
                <Icon size={18} />
                {!collapsed && <span>{label}</span>}
              </motion.div>
            )}
          </NavLink>
        ))}
      </nav>

      {!collapsed && contractData.address && (
        <div className="sidebar-contract">
          <span className="sidebar-contract-label">Contract</span>
          <code>{contractData.address.slice(0, 8)}...{contractData.address.slice(-4)}</code>
        </div>
      )}

      <div className="sidebar-footer">
        <button type="button" className="sidebar-logout" onClick={handleLogout}>
          <LogOut size={18} />
          {!collapsed && <span>Logout</span>}
        </button>
        <button
          type="button"
          className="sidebar-toggle"
          onClick={() => setCollapsed((c) => !c)}
          aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
        </button>
      </div>
    </motion.aside>
  );
}
