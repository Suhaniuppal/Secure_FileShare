import { Link, useLocation, Outlet } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { Shield } from 'lucide-react';
import Sidebar from './Sidebar';
import CyberBackground from './CyberBackground';
import PageTransition from './PageTransition';

export default function Layout() {
  const location = useLocation();

  return (
    <div className="app-layout">
      <CyberBackground />
      <Sidebar />

      <div className="app-main">
        <header className="topbar">
          <Link to="/dashboard" className="topbar-brand">
            <motion.div
              className="topbar-logo"
              whileHover={{ scale: 1.05, rotate: 2 }}
              whileTap={{ scale: 0.97 }}
            >
              <Shield size={20} />
            </motion.div>
            <span>SecureShare</span>
          </Link>
          <div className="topbar-spacer" />
        </header>

        <div className="app-content">
          <AnimatePresence mode="wait">
            <PageTransition key={location.pathname}>
              <Outlet />
            </PageTransition>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
