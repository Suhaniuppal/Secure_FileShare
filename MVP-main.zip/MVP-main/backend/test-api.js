/**
 * Run after backend is up and database/setup.sql has been applied:
 *   node test-api.js
 */
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const http = require('http');

const BASE = `http://localhost:${process.env.PORT || 5000}/api`;

function request(method, urlPath, { token, body, form } = {}) {
  return new Promise((resolve, reject) => {
    const url = new URL(BASE + urlPath);
    const headers = {};

    if (token) headers.Authorization = `Bearer ${token}`;
    if (body) headers['Content-Type'] = 'application/json';

    let payload;
    if (form) {
      const boundary = '----FormBoundary' + Date.now();
      headers['Content-Type'] = `multipart/form-data; boundary=${boundary}`;
      const parts = [];
      for (const [key, value] of Object.entries(form)) {
        if (key === 'file') {
          const content = fs.readFileSync(value);
          parts.push(
            `--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${path.basename(value)}"\r\nContent-Type: application/octet-stream\r\n\r\n`
          );
          parts.push(content);
          parts.push('\r\n');
        } else {
          parts.push(
            `--${boundary}\r\nContent-Disposition: form-data; name="${key}"\r\n\r\n${value}\r\n`
          );
        }
      }
      parts.push(`--${boundary}--\r\n`);
      payload = Buffer.concat(
        parts.map((p) => (typeof p === 'string' ? Buffer.from(p) : p))
      );
      headers['Content-Length'] = payload.length;
    } else if (body) {
      payload = Buffer.from(JSON.stringify(body));
      headers['Content-Length'] = payload.length;
    }

    const req = http.request(
      { hostname: url.hostname, port: url.port, path: url.pathname, method, headers },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks);
          const text = raw.toString('utf8');
          let data = text;
          try {
            data = JSON.parse(text);
          } catch {
            /* binary or plain text */
          }
          if (res.statusCode >= 400) {
            reject({ status: res.statusCode, data });
          } else {
            resolve({ status: res.statusCode, data, raw });
          }
        });
      }
    );
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

async function run() {
  const stamp = Date.now();
  const user1 = {
    username: `amit_${stamp}`,
    email: `amit_${stamp}@test.com`,
    password: '123456',
    wallet_address: '0x1111111111111111111111111111111111111111',
  };
  const user2 = {
    username: `bob_${stamp}`,
    email: `bob_${stamp}@test.com`,
    password: '123456',
    wallet_address: '0x2222222222222222222222222222222222222222',
  };

  console.log('1. Register user 1...');
  const reg1 = await request('POST', '/auth/register', { body: user1 });
  console.log('   OK - token received');

  console.log('   Register user 2...');
  const reg2 = await request('POST', '/auth/register', { body: user2 });
  console.log(`   OK - id=${reg2.data.user.id}`);

  console.log('2. Login...');
  const login = await request('POST', '/auth/login', {
    body: { email: user1.email, password: user1.password },
  });
  const token = login.data.token;
  console.log('   OK - JWT received');

  console.log('3. GET /auth/users...');
  const users = await request('GET', '/auth/users', { token });
  console.log(`   OK - ${users.data.length} user(s)`);

  console.log('4. POST /files/upload...');
  const testFile = path.join(__dirname, 'uploads', 'test-api.txt');
  fs.writeFileSync(testFile, 'Hello MVP test file');
  const upload = await request('POST', '/files/upload', {
    token,
    form: { file: testFile, receiver_id: String(reg2.data.user.id) },
  });
  console.log(`   OK - file id=${upload.data.file.id}`);

  console.log('5. GET /files/my-uploads...');
  const myUploads = await request('GET', '/files/my-uploads', { token });
  console.log(`   OK - ${myUploads.data.length} upload(s)`);

  console.log('6. GET /files/shared (as user 2)...');
  const bobLogin = await request('POST', '/auth/login', {
    body: { email: user2.email, password: user2.password },
  });
  const shared = await request('GET', '/files/shared', { token: bobLogin.data.token });
  console.log(`   OK - ${shared.data.length} shared file(s)`);

  console.log('7. GET /files/download/:id...');
  const fileId = shared.data[0].id;
  const download = await request('GET', `/files/download/${fileId}`, {
    token: bobLogin.data.token,
  });
  console.log(`   OK - content="${download.raw.toString()}"`);

  console.log('\nAll 7 API tests PASSED');
}

run().catch((err) => {
  console.error('\nAPI test FAILED:', err.data || err.message || err);
  console.error('\nIf you see "Unknown column username", run database/setup.sql in MySQL Workbench first.');
  process.exit(1);
});
