const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const pool = require('../config/db');
const authMiddleware = require('../middleware/auth');
const { encrypt, decrypt, hashFile } = require('../utils/encryption');


const router = express.Router();
const uploadDir = path.join(__dirname, '..', 'uploads');

const { ethers } = require("ethers");
const contractData = require("../contracts/FileShare.json");

const provider = new ethers.JsonRpcProvider("http://127.0.0.1:8545");

const wallet = new ethers.Wallet(
    process.env.PRIVATE_KEY,
    provider
);

const contract = new ethers.Contract(
    process.env.CONTRACT_ADDRESS,
    contractData.abi,
    wallet
);

if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const upload = multer({ storage: multer.memoryStorage() });

router.post('/upload', authMiddleware, upload.single('file'), async (req, res) => {
  try {
    const { receiver_id } = req.body;

    if (!req.file || !receiver_id) {
      return res.status(400).json({ error: 'File and receiver are required.' });
    }

    const [receivers] = await pool.query('SELECT id, wallet_address FROM Users WHERE id = ?', [
      receiver_id,
    ]);
    if (receivers.length === 0) {
      return res.status(404).json({ error: 'Receiver not found.' });
    }

    const fileHash = hashFile(req.file.buffer);
    const encrypted = encrypt(req.file.buffer);
    const encryptedFilename = `${Date.now()}_${req.file.originalname}.enc`;
    const filepath = path.join(uploadDir, encryptedFilename);

    fs.writeFileSync(filepath, encrypted);

    const [result] = await pool.query(
      `INSERT INTO Files (owner_id, receiver_id, filename, encrypted_filename, filepath, hash)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [
        req.user.id,
        receiver_id,
        req.file.originalname,
        encryptedFilename,
        filepath,
        fileHash,
      ]
    );
    
    // ---------- Blockchain ----------
    const tx = await contract.shareFile(
        receivers[0].wallet_address,
        req.file.originalname,
        fileHash
    );
    
    await tx.wait();
    
    console.log("Blockchain Transaction:", tx.hash);
    // -------------------------------

    res.status(201).json({
      file: {
        id: result.insertId,
        filename: req.file.originalname,
        hash: fileHash,
        receiver_wallet: receivers[0].wallet_address,
      },
    });
  } catch (err) {
    console.error('Upload error:', err);
    res.status(500).json({ error: 'Upload failed.' });
  }
});

router.get('/my-uploads', authMiddleware, async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT f.id, f.filename, f.hash, f.created_at, u.username AS receiver_name
       FROM Files f
       JOIN Users u ON f.receiver_id = u.id
       WHERE f.owner_id = ?
       ORDER BY f.created_at DESC`,
      [req.user.id]
    );
    res.json(rows);
  } catch (err) {
    console.error('My uploads error:', err);
    res.status(500).json({ error: 'Failed to fetch uploads.' });
  }
});

router.get('/shared', authMiddleware, async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT f.id, f.filename, f.hash, f.created_at, u.username AS owner_name
       FROM Files f
       JOIN Users u ON f.owner_id = u.id
       WHERE f.receiver_id = ?
       ORDER BY f.created_at DESC`,
      [req.user.id]
    );
    res.json(rows);
  } catch (err) {
    console.error('Shared files error:', err);
    res.status(500).json({ error: 'Failed to fetch shared files.' });
  }
});

router.get('/download/:id', authMiddleware, async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM Files WHERE id = ?', [req.params.id]);
    if (rows.length === 0) {
      return res.status(404).json({ error: 'File not found.' });
    }

    const file = rows[0];
    if (file.receiver_id !== req.user.id && file.owner_id !== req.user.id) {
      return res.status(403).json({ error: 'Access denied.' });
    }

    if (!fs.existsSync(file.filepath)) {
      return res.status(404).json({ error: 'Encrypted file missing on server.' });
    }

    const encrypted = fs.readFileSync(file.filepath);
    const decrypted = decrypt(encrypted);

    res.setHeader('Content-Disposition', `attachment; filename="${file.filename}"`);
    res.setHeader('Content-Type', 'application/octet-stream');
    res.send(decrypted);
  } catch (err) {
    console.error('Download error:', err);
    res.status(500).json({ error: 'Download failed.' });
  }
});

router.get('/stats', authMiddleware, async (req, res) => {
  try {
    const [[uploads]] = await pool.query(
      'SELECT COUNT(*) AS count FROM Files WHERE owner_id = ?',
      [req.user.id]
    );
    const [[shared]] = await pool.query(
      'SELECT COUNT(*) AS count FROM Files WHERE receiver_id = ?',
      [req.user.id]
    );
    res.json({ uploads: uploads.count, shared: shared.count });
  } catch (err) {
    console.error('Stats error:', err);
    res.status(500).json({ error: 'Failed to fetch stats.' });
  }
});

module.exports = router;
