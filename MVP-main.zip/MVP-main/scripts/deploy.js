const hre = require("hardhat");
const fs = require("fs");
const path = require("path");

async function main() {
  const FileShare = await hre.ethers.getContractFactory("FileShare");
  const fileShare = await FileShare.deploy();
  await fileShare.waitForDeployment();

  const address = await fileShare.getAddress();
  console.log("FileShare deployed to:", address);

  const artifactPath = path.join(
    __dirname,
    "..",
    "frontend",
    "src",
    "contract",
    "FileShare.json"
  );

  const artifact = await hre.artifacts.readArtifact("FileShare");
  fs.mkdirSync(path.dirname(artifactPath), { recursive: true });
  fs.writeFileSync(
    artifactPath,
    JSON.stringify({ address, abi: artifact.abi }, null, 2)
  );

  console.log("Contract ABI saved to frontend/src/contract/FileShare.json");
  console.log("\nAdd this to backend/.env:");
  console.log(`CONTRACT_ADDRESS=${address}`);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
